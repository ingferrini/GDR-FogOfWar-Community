@echo off
cd /d "%~dp0"
where node >nul 2>nul
if errorlevel 1 (
  echo Node.js non trovato / Node.js not found.
  echo Installa Node.js 20.19+ o 22.12+ da https://nodejs.org/
  pause
  exit /b 1
)
echo Apri / Open: http://127.0.0.1:5173
node server.mjs
pause
