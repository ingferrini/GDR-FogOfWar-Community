GDR FogOfWar v1.0.0
======================

ITA
---
1. Estrai TUTTO lo ZIP in una cartella locale.
2. Installa Node.js 20.19+ o 22.12+ se non è già presente.
3. Avvia start-windows.bat e lascia aperta la finestra del server.
4. Apri http://127.0.0.1:5173 in Edge o Chrome.
5. Per fermare il server premi Ctrl+C nella sua finestra.

Prima di aggiornare, esporta i progetti importanti come .fogproject.zip.
Lo strumento è destinato a sessioni dal vivo con schermo o proiettore; non è un VTT.

ENG
---
1. Extract the ENTIRE ZIP to a local folder.
2. Install Node.js 20.19+ or 22.12+ if it is not already installed.
3. Run start-windows.bat and keep the server window open.
4. Open http://127.0.0.1:5173 in Edge or Chrome.
5. Press Ctrl+C in the server window to stop it.

Export important projects as .fogproject.zip before updating.
This tool is intended for in-person play with a display or projector; it is not a VTT.

Novita / What's new
--------------------
Prima versione stabile con controllo Sessione pronta?, progetti più sicuri,
backup automatici, update PWA espliciti, palette puntatore e diagnostica.

First stable release with Session ready?, safer projects, automatic backups,
explicit PWA updates, pointer palette, and privacy-safe diagnostics.

Licence / Licenza
------------------
PolyForm Strict License 1.0.0. Personal and noncommercial use only.
See LICENSE.txt. Commercial permission: https://github.com/ingferrini
